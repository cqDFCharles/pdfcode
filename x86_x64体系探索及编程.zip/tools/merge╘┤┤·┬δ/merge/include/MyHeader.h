#ifndef MYHEADER_H
#define MYHEADER_H

#include <Windows.h>
#include <BaseTsd.h>
#include <tchar.h>
#include <stdio.h>


#endif